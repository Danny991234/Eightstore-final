import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../config/app_theme.dart';
import '../../providers/auth_provider.dart';

class OtpLoginScreen extends StatefulWidget {
  const OtpLoginScreen({super.key});

  @override
  State<OtpLoginScreen> createState() => _OtpLoginScreenState();
}

class _OtpLoginScreenState extends State<OtpLoginScreen> {
  final _phoneController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  bool _loading = false;

  Future<void> _sendOtp() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _loading = true);
    final phone = '+91${_phoneController.text.trim()}';
    final error = await context.read<AuthProvider>().sendOtp(phone);
    setState(() => _loading = false);
    if (!mounted) return;
    if (error != null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(error), backgroundColor: AppColors.error));
    } else {
      context.push('/verify-otp', extra: phone);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 60),
                // Logo
                Row(
                  children: [
                    Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        color: AppColors.primary,
                        border: Border.all(color: AppColors.accent, width: 1.5),
                      ),
                      child: const Center(
                        child: Text('8', style: TextStyle(fontFamily: 'Playfair', fontSize: 28, color: AppColors.accent, height: 1, fontWeight: FontWeight.w700)),
                      ),
                    ),
                    const SizedBox(width: 12),
                    const Text('STORE', style: TextStyle(fontFamily: 'Urbanist', fontSize: 18, fontWeight: FontWeight.w700, letterSpacing: 5, color: AppColors.primary)),
                  ],
                ),
                const SizedBox(height: 56),
                const Text('Welcome', style: TextStyle(fontFamily: 'Playfair', fontSize: 32, fontWeight: FontWeight.w700, color: AppColors.primary)),
                const SizedBox(height: 8),
                const Text('Enter your mobile number to continue', style: TextStyle(fontSize: 15, color: AppColors.textSecondary)),
                const SizedBox(height: 40),
                // Phone input
                Container(
                  decoration: BoxDecoration(
                    border: Border.all(color: AppColors.divider),
                    color: AppColors.surface,
                  ),
                  child: Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 18),
                        decoration: const BoxDecoration(
                          border: Border(right: BorderSide(color: AppColors.divider)),
                        ),
                        child: const Text('+91', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600, color: AppColors.primary)),
                      ),
                      Expanded(
                        child: TextFormField(
                          controller: _phoneController,
                          keyboardType: TextInputType.phone,
                          inputFormatters: [FilteringTextInputFormatter.digitsOnly, LengthLimitingTextInputFormatter(10)],
                          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                          decoration: const InputDecoration(
                            border: InputBorder.none,
                            contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 18),
                            hintText: '10 digit mobile number',
                            hintStyle: TextStyle(color: AppColors.textSecondary, fontSize: 14),
                          ),
                          validator: (v) => (v == null || v.length != 10) ? 'Enter valid 10-digit mobile number' : null,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 32),
                // Send OTP button
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _loading ? null : _sendOtp,
                    child: _loading
                        ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                        : const Text('SEND OTP'),
                  ),
                ),
                const SizedBox(height: 20),
                // Guest login
                Center(
                  child: TextButton(
                    onPressed: () {
                      context.read<AuthProvider>().continueAsGuest();
                      context.go('/home');
                    },
                    child: const Text('Continue as Guest →', style: TextStyle(color: AppColors.textSecondary, fontWeight: FontWeight.w600)),
                  ),
                ),
                const Spacer(),
                Center(
                  child: Text(
                    'By continuing, you agree to our Terms & Privacy Policy',
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 12, color: AppColors.textSecondary),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
