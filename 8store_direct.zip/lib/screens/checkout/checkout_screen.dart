import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../config/app_theme.dart';
import '../../models/models.dart';
import '../../providers/auth_provider.dart';
import '../../providers/cart_provider.dart';
import '../../providers/order_provider.dart';

class CheckoutScreen extends StatefulWidget {
  const CheckoutScreen({super.key});

  @override
  State<CheckoutScreen> createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends State<CheckoutScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameCtrl = TextEditingController();
  final _phoneCtrl = TextEditingController();
  final _line1Ctrl = TextEditingController();
  final _line2Ctrl = TextEditingController();
  final _cityCtrl = TextEditingController();
  final _stateCtrl = TextEditingController();
  final _pincodeCtrl = TextEditingController();
  String _paymentMethod = 'COD';
  AddressModel? _selectedAddress;
  bool _useNewAddress = true;

  @override
  void initState() {
    super.initState();
    final user = context.read<AuthProvider>().user;
    if (user != null) {
      _phoneCtrl.text = user.phone.replaceAll('+91', '');
      _nameCtrl.text = user.name;
      final defaultAddr = user.addresses.where((a) => a.isDefault).toList();
      if (defaultAddr.isNotEmpty) {
        _selectedAddress = defaultAddr.first;
        _useNewAddress = false;
      }
    }
  }

  Future<void> _placeOrder() async {
    if (_useNewAddress && !_formKey.currentState!.validate()) return;

    final cart = context.read<CartProvider>();
    final auth = context.read<AuthProvider>();
    final orders = context.read<OrderProvider>();

    final address = _useNewAddress
        ? AddressModel(
            id: DateTime.now().millisecondsSinceEpoch.toString(),
            fullName: _nameCtrl.text.trim(),
            phone: _phoneCtrl.text.trim(),
            line1: _line1Ctrl.text.trim(),
            line2: _line2Ctrl.text.trim(),
            city: _cityCtrl.text.trim(),
            state: _stateCtrl.text.trim(),
            pincode: _pincodeCtrl.text.trim(),
          )
        : _selectedAddress!;

    final order = OrderModel(
      id: '',
      userId: auth.user!.id,
      userPhone: auth.user!.phone,
      items: cart.items.toList(),
      deliveryAddress: address,
      subtotal: cart.subtotal,
      deliveryCharge: cart.deliveryCharge,
      total: cart.total,
      paymentMethod: _paymentMethod,
      createdAt: DateTime.now(),
    );

    final orderId = await orders.placeOrder(order);
    if (!mounted) return;

    if (orderId != null) {
      cart.clear();
      context.go('/order-success', extra: orderId);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Failed to place order. Please try again.'), backgroundColor: AppColors.error),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final cart = context.watch<CartProvider>();
    final auth = context.watch<AuthProvider>();
    final orders = context.watch<OrderProvider>();
    final hasAddresses = auth.user?.addresses.isNotEmpty == true;

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('Checkout', style: TextStyle(fontFamily: 'Playfair')),
        leading: IconButton(icon: const Icon(Icons.arrow_back_ios, size: 18), onPressed: () => context.pop()),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Saved Addresses
              if (hasAddresses && !_useNewAddress) ...[
                _SectionHeader('Delivery Address'),
                const SizedBox(height: 12),
                ...auth.user!.addresses.map((addr) => _AddressTile(
                  address: addr,
                  isSelected: _selectedAddress?.id == addr.id,
                  onSelect: () => setState(() => _selectedAddress = addr),
                )),
                const SizedBox(height: 8),
                TextButton.icon(
                  onPressed: () => setState(() => _useNewAddress = true),
                  icon: const Icon(Icons.add, size: 18),
                  label: const Text('Add New Address'),
                  style: TextButton.styleFrom(foregroundColor: AppColors.primary),
                ),
                const SizedBox(height: 24),
              ] else ...[
                _SectionHeader('Delivery Address'),
                const SizedBox(height: 16),
                // Form
                _InputField(controller: _nameCtrl, label: 'Full Name', required: true),
                const SizedBox(height: 12),
                _InputField(controller: _phoneCtrl, label: 'Phone', keyboardType: TextInputType.phone, required: true),
                const SizedBox(height: 12),
                _InputField(controller: _line1Ctrl, label: 'Address Line 1', required: true),
                const SizedBox(height: 12),
                _InputField(controller: _line2Ctrl, label: 'Address Line 2 (Optional)'),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(child: _InputField(controller: _cityCtrl, label: 'City', required: true)),
                    const SizedBox(width: 12),
                    Expanded(child: _InputField(controller: _stateCtrl, label: 'State', required: true)),
                  ],
                ),
                const SizedBox(height: 12),
                _InputField(controller: _pincodeCtrl, label: 'Pincode', keyboardType: TextInputType.number, required: true),
                const SizedBox(height: 24),
              ],

              const Divider(color: AppColors.divider),
              const SizedBox(height: 20),

              // Payment Method
              _SectionHeader('Payment Method'),
              const SizedBox(height: 12),
              _PaymentOption(
                label: 'Cash on Delivery (COD)',
                subtitle: 'Pay when you receive your order',
                icon: Icons.money,
                isSelected: _paymentMethod == 'COD',
                onTap: () => setState(() => _paymentMethod = 'COD'),
              ),
              const SizedBox(height: 8),
              _PaymentOption(
                label: 'Online Payment',
                subtitle: 'Coming soon - UPI, Cards, Net Banking',
                icon: Icons.credit_card,
                isSelected: _paymentMethod == 'ONLINE',
                isDisabled: true,
                onTap: () {},
              ),

              const SizedBox(height: 24),
              const Divider(color: AppColors.divider),
              const SizedBox(height: 20),

              // Order Summary
              _SectionHeader('Order Summary'),
              const SizedBox(height: 12),
              ...cart.items.map((item) => Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(child: Text('${item.productName} (${item.size}) × ${item.quantity}', style: const TextStyle(fontSize: 13), maxLines: 1, overflow: TextOverflow.ellipsis)),
                    Text('₹${item.total.toStringAsFixed(0)}', style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
                  ],
                ),
              )),
              const Divider(color: AppColors.divider),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('Delivery', style: TextStyle(fontSize: 13, color: AppColors.textSecondary)),
                  Text(cart.deliveryCharge == 0 ? 'FREE' : '₹${cart.deliveryCharge.toStringAsFixed(0)}',
                      style: TextStyle(fontWeight: FontWeight.w600, fontSize: 13, color: cart.deliveryCharge == 0 ? AppColors.success : null)),
                ],
              ),
              const SizedBox(height: 6),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('Total', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                  Text('₹${cart.total.toStringAsFixed(0)}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
                ],
              ),

              const SizedBox(height: 32),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: orders.isLoading ? null : _placeOrder,
                  child: orders.isLoading
                      ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                      : Text('PLACE ORDER • ₹${cart.total.toStringAsFixed(0)}'),
                ),
              ),
              const SizedBox(height: 32),
            ],
          ),
        ),
      ),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  final String title;
  const _SectionHeader(this.title);

  @override
  Widget build(BuildContext context) {
    return Text(title, style: const TextStyle(fontFamily: 'Urbanist', fontSize: 13, fontWeight: FontWeight.w700, letterSpacing: 1.5));
  }
}

class _InputField extends StatelessWidget {
  final TextEditingController controller;
  final String label;
  final bool required;
  final TextInputType? keyboardType;

  const _InputField({required this.controller, required this.label, this.required = false, this.keyboardType});

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: controller,
      keyboardType: keyboardType,
      decoration: InputDecoration(
        labelText: label,
        labelStyle: const TextStyle(fontSize: 13, color: AppColors.textSecondary),
        border: const OutlineInputBorder(borderSide: BorderSide(color: AppColors.divider)),
        focusedBorder: const OutlineInputBorder(borderSide: BorderSide(color: AppColors.primary)),
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        filled: true,
        fillColor: AppColors.surface,
      ),
      validator: required ? (v) => (v == null || v.isEmpty) ? 'Required' : null : null,
    );
  }
}

class _PaymentOption extends StatelessWidget {
  final String label, subtitle;
  final IconData icon;
  final bool isSelected, isDisabled;
  final VoidCallback onTap;

  const _PaymentOption({required this.label, required this.subtitle, required this.icon, required this.isSelected, this.isDisabled = false, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: isDisabled ? null : onTap,
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          border: Border.all(color: isSelected ? AppColors.primary : AppColors.divider, width: isSelected ? 2 : 1),
          color: isDisabled ? AppColors.cardBg : AppColors.surface,
        ),
        child: Row(
          children: [
            Icon(icon, size: 24, color: isDisabled ? AppColors.textSecondary : AppColors.primary),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(label, style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14, color: isDisabled ? AppColors.textSecondary : AppColors.textPrimary)),
                  Text(subtitle, style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                ],
              ),
            ),
            if (!isDisabled) Radio(value: true, groupValue: isSelected, onChanged: (_) => onTap(), activeColor: AppColors.primary),
            if (isDisabled) const Text('SOON', style: TextStyle(fontSize: 10, fontWeight: FontWeight.w700, color: AppColors.textSecondary, letterSpacing: 1)),
          ],
        ),
      ),
    );
  }
}

class _AddressTile extends StatelessWidget {
  final AddressModel address;
  final bool isSelected;
  final VoidCallback onSelect;

  const _AddressTile({required this.address, required this.isSelected, required this.onSelect});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onSelect,
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          border: Border.all(color: isSelected ? AppColors.primary : AppColors.divider, width: isSelected ? 2 : 1),
          color: AppColors.surface,
        ),
        child: Row(
          children: [
            Radio(value: true, groupValue: isSelected, onChanged: (_) => onSelect(), activeColor: AppColors.primary),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(address.fullName, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
                  const SizedBox(height: 2),
                  Text('${address.line1}, ${address.city}, ${address.state} - ${address.pincode}',
                      style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                  Text(address.phone, style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
