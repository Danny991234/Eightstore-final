import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../config/app_theme.dart';

class OrderSuccessScreen extends StatelessWidget {
  final String orderId;
  const OrderSuccessScreen({super.key, required this.orderId});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 100,
                height: 100,
                decoration: BoxDecoration(color: const Color(0xFFE8F5E9), shape: BoxShape.circle),
                child: const Icon(Icons.check, size: 56, color: AppColors.success),
              ),
              const SizedBox(height: 28),
              const Text('Order Placed!', style: TextStyle(fontFamily: 'Playfair', fontSize: 28, fontWeight: FontWeight.w700)),
              const SizedBox(height: 12),
              const Text(
                'Your order has been confirmed.\nWe\'ll notify you when it\'s packed and shipped.',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 15, color: AppColors.textSecondary, height: 1.6),
              ),
              const SizedBox(height: 24),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
                color: AppColors.cardBg,
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text('Order ID: ', style: TextStyle(fontSize: 13, color: AppColors.textSecondary)),
                    Text(orderId.length > 12 ? orderId.substring(0, 12) + '...' : orderId,
                        style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700)),
                  ],
                ),
              ),
              const SizedBox(height: 40),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () => context.go('/order/$orderId'),
                  child: const Text('TRACK ORDER'),
                ),
              ),
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton(
                  style: OutlinedButton.styleFrom(
                    side: const BorderSide(color: AppColors.primary),
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
                  ),
                  onPressed: () => context.go('/home'),
                  child: const Text('CONTINUE SHOPPING', style: TextStyle(color: AppColors.primary, fontWeight: FontWeight.w700, letterSpacing: 1)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
