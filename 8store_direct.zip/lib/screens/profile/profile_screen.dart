import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../config/app_theme.dart';
import '../../providers/auth_provider.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: const Text('Profile', style: TextStyle(fontFamily: 'Playfair'))),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(28),
              color: AppColors.primary,
              child: Column(
                children: [
                  Container(
                    width: 72,
                    height: 72,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(color: AppColors.accent, width: 2),
                      color: Colors.white12,
                    ),
                    child: Center(
                      child: Text(
                        auth.isGuest ? 'G' : (auth.user?.name.isNotEmpty == true ? auth.user!.name[0].toUpperCase() : '?'),
                        style: const TextStyle(fontFamily: 'Playfair', fontSize: 32, color: AppColors.accent, fontWeight: FontWeight.w700),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    auth.isGuest ? 'Guest User' : (auth.user?.name.isEmpty == true ? 'Set Your Name' : auth.user!.name),
                    style: const TextStyle(fontFamily: 'Playfair', fontSize: 18, color: Colors.white, fontWeight: FontWeight.w700),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    auth.isGuest ? '' : (auth.user?.phone ?? ''),
                    style: const TextStyle(fontSize: 13, color: Colors.white54),
                  ),
                ],
              ),
            ),

            if (auth.isGuest) ...[
              const SizedBox(height: 40),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Column(
                  children: [
                    const Text('Login to access all features', style: TextStyle(fontSize: 16, color: AppColors.textSecondary)),
                    const SizedBox(height: 20),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed: () => context.go('/login'),
                        child: const Text('LOGIN / SIGN UP'),
                      ),
                    ),
                  ],
                ),
              ),
            ] else ...[
              _MenuTile(icon: Icons.location_on_outlined, label: 'My Addresses', onTap: () => context.push('/address')),
              _MenuTile(icon: Icons.receipt_long_outlined, label: 'My Orders', onTap: () => context.go('/orders')),
              _MenuTile(icon: Icons.notifications_outlined, label: 'Notifications', onTap: () {}),
              _MenuTile(icon: Icons.help_outline, label: 'Help & Support', onTap: () {}),
              const Divider(color: AppColors.divider),
              _MenuTile(icon: Icons.logout, label: 'Logout', onTap: () async {
                await auth.signOut();
                if (context.mounted) context.go('/login');
              }, isDestructive: true),
            ],
          ],
        ),
      ),
    );
  }
}

class _MenuTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final bool isDestructive;

  const _MenuTile({required this.icon, required this.label, required this.onTap, this.isDestructive = false});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      tileColor: AppColors.surface,
      leading: Icon(icon, color: isDestructive ? AppColors.error : AppColors.textPrimary, size: 22),
      title: Text(label, style: TextStyle(fontSize: 14, fontWeight: FontWeight.w500, color: isDestructive ? AppColors.error : AppColors.textPrimary)),
      trailing: const Icon(Icons.chevron_right, color: AppColors.textSecondary, size: 20),
      onTap: onTap,
    );
  }
}
