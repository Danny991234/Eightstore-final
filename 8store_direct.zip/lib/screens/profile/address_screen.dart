import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../config/app_theme.dart';
import '../../models/models.dart';
import '../../providers/auth_provider.dart';

class AddressScreen extends StatelessWidget {
  const AddressScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final addresses = auth.user?.addresses ?? [];

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: const Text('My Addresses', style: TextStyle(fontFamily: 'Playfair'))),
      floatingActionButton: FloatingActionButton(
        backgroundColor: AppColors.primary,
        onPressed: () => _showAddressDialog(context, auth),
        child: const Icon(Icons.add, color: Colors.white),
      ),
      body: addresses.isEmpty
          ? const Center(child: Text('No saved addresses', style: TextStyle(color: AppColors.textSecondary)))
          : ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: addresses.length,
              separatorBuilder: (_, __) => const SizedBox(height: 12),
              itemBuilder: (_, idx) {
                final addr = addresses[idx];
                return Container(
                  padding: const EdgeInsets.all(16),
                  color: AppColors.surface,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(addr.fullName, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
                          if (addr.isDefault)
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                              color: AppColors.primary,
                              child: const Text('DEFAULT', style: TextStyle(fontSize: 10, color: Colors.white, fontWeight: FontWeight.w700, letterSpacing: 1)),
                            ),
                        ],
                      ),
                      const SizedBox(height: 6),
                      Text(addr.formatted, style: const TextStyle(fontSize: 13, color: AppColors.textSecondary, height: 1.6)),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          TextButton(
                            onPressed: () => auth.removeAddress(addr.id),
                            style: TextButton.styleFrom(foregroundColor: AppColors.error, padding: EdgeInsets.zero),
                            child: const Text('Remove'),
                          ),
                        ],
                      ),
                    ],
                  ),
                );
              },
            ),
    );
  }

  void _showAddressDialog(BuildContext context, AuthProvider auth) {
    final nameCtrl = TextEditingController();
    final phoneCtrl = TextEditingController();
    final line1Ctrl = TextEditingController();
    final cityCtrl = TextEditingController();
    final stateCtrl = TextEditingController();
    final pincodeCtrl = TextEditingController();
    final formKey = GlobalKey<FormState>();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: AppColors.surface,
      builder: (ctx) => Padding(
        padding: EdgeInsets.fromLTRB(20, 20, 20, MediaQuery.of(ctx).viewInsets.bottom + 20),
        child: Form(
          key: formKey,
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text('Add Address', style: TextStyle(fontFamily: 'Playfair', fontSize: 20, fontWeight: FontWeight.w700)),
                const SizedBox(height: 16),
                _field(nameCtrl, 'Full Name'),
                const SizedBox(height: 10),
                _field(phoneCtrl, 'Phone', keyboardType: TextInputType.phone),
                const SizedBox(height: 10),
                _field(line1Ctrl, 'Address'),
                const SizedBox(height: 10),
                Row(children: [
                  Expanded(child: _field(cityCtrl, 'City')),
                  const SizedBox(width: 10),
                  Expanded(child: _field(stateCtrl, 'State')),
                ]),
                const SizedBox(height: 10),
                _field(pincodeCtrl, 'Pincode', keyboardType: TextInputType.number),
                const SizedBox(height: 20),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () async {
                      if (!formKey.currentState!.validate()) return;
                      await auth.addAddress(AddressModel(
                        id: DateTime.now().millisecondsSinceEpoch.toString(),
                        fullName: nameCtrl.text.trim(),
                        phone: phoneCtrl.text.trim(),
                        line1: line1Ctrl.text.trim(),
                        city: cityCtrl.text.trim(),
                        state: stateCtrl.text.trim(),
                        pincode: pincodeCtrl.text.trim(),
                        isDefault: auth.user?.addresses.isEmpty == true,
                      ));
                      if (ctx.mounted) Navigator.pop(ctx);
                    },
                    child: const Text('SAVE ADDRESS'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _field(TextEditingController ctrl, String label, {TextInputType? keyboardType}) {
    return TextFormField(
      controller: ctrl,
      keyboardType: keyboardType,
      decoration: InputDecoration(
        labelText: label,
        border: const OutlineInputBorder(),
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      ),
      validator: (v) => v?.isEmpty == true ? 'Required' : null,
    );
  }
}
