import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../config/app_theme.dart';
import '../../providers/cart_provider.dart';
import '../../providers/auth_provider.dart';

class CartScreen extends StatelessWidget {
  const CartScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final cart = context.watch<CartProvider>();
    final auth = context.watch<AuthProvider>();

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: Text('Cart (${cart.itemCount})', style: const TextStyle(fontFamily: 'Playfair')),
        actions: [
          if (!cart.isEmpty)
            TextButton(
              onPressed: () => showDialog(
                context: context,
                builder: (_) => AlertDialog(
                  title: const Text('Clear Cart?'),
                  content: const Text('Remove all items from cart?'),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
                    TextButton(onPressed: () { cart.clear(); Navigator.pop(context); }, child: const Text('Clear', style: TextStyle(color: AppColors.error))),
                  ],
                ),
              ),
              child: const Text('Clear', style: TextStyle(color: AppColors.error, fontSize: 13)),
            ),
        ],
      ),
      body: cart.isEmpty
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.shopping_bag_outlined, size: 72, color: AppColors.divider),
                  const SizedBox(height: 16),
                  const Text('Your cart is empty', style: TextStyle(fontFamily: 'Playfair', fontSize: 20, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 8),
                  const Text('Add some items to continue', style: TextStyle(color: AppColors.textSecondary)),
                  const SizedBox(height: 24),
                  ElevatedButton(
                    onPressed: () => context.go('/products'),
                    child: const Text('SHOP NOW'),
                  ),
                ],
              ),
            )
          : Column(
              children: [
                Expanded(
                  child: ListView.separated(
                    padding: const EdgeInsets.all(16),
                    itemCount: cart.items.length,
                    separatorBuilder: (_, __) => const Divider(color: AppColors.divider),
                    itemBuilder: (_, idx) {
                      final item = cart.items[idx];
                      return Row(
                        children: [
                          // Image
                          Container(
                            width: 80,
                            height: 100,
                            color: AppColors.cardBg,
                            child: CachedNetworkImage(
                              imageUrl: item.productImage,
                              fit: BoxFit.cover,
                              errorWidget: (_, __, ___) => const Icon(Icons.image_outlined, color: AppColors.textSecondary),
                            ),
                          ),
                          const SizedBox(width: 14),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(item.productName, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14), maxLines: 2, overflow: TextOverflow.ellipsis),
                                const SizedBox(height: 4),
                                Text('Size: ${item.size}', style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                                const SizedBox(height: 4),
                                Text('₹${item.price.toStringAsFixed(0)}', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
                                const SizedBox(height: 10),
                                // Quantity
                                Row(
                                  children: [
                                    _QtyBtn(icon: Icons.remove, onTap: () => cart.updateQuantity(item.cartKey, item.quantity - 1)),
                                    Container(
                                      width: 36,
                                      height: 32,
                                      alignment: Alignment.center,
                                      decoration: BoxDecoration(border: Border.all(color: AppColors.divider)),
                                      child: Text('${item.quantity}', style: const TextStyle(fontWeight: FontWeight.w700)),
                                    ),
                                    _QtyBtn(icon: Icons.add, onTap: () => cart.updateQuantity(item.cartKey, item.quantity + 1)),
                                    const Spacer(),
                                    IconButton(
                                      icon: const Icon(Icons.delete_outline, color: AppColors.error, size: 20),
                                      onPressed: () => cart.removeItem(item.cartKey),
                                      padding: EdgeInsets.zero,
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ],
                      );
                    },
                  ),
                ),
                // Order Summary
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: const BoxDecoration(
                    color: AppColors.surface,
                    border: Border(top: BorderSide(color: AppColors.divider)),
                  ),
                  child: SafeArea(
                    child: Column(
                      children: [
                        _SummaryRow('Subtotal', '₹${cart.subtotal.toStringAsFixed(0)}'),
                        const SizedBox(height: 6),
                        _SummaryRow('Delivery', cart.deliveryCharge == 0 ? 'FREE' : '₹${cart.deliveryCharge.toStringAsFixed(0)}', valueColor: cart.deliveryCharge == 0 ? AppColors.success : null),
                        const Padding(padding: EdgeInsets.symmetric(vertical: 10), child: Divider(color: AppColors.divider)),
                        _SummaryRow('Total', '₹${cart.total.toStringAsFixed(0)}', bold: true),
                        const SizedBox(height: 16),
                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton(
                            onPressed: () {
                              if (auth.isGuest) {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(content: Text('Please login to checkout')),
                                );
                                context.go('/login');
                              } else {
                                context.push('/checkout');
                              }
                            },
                            child: const Text('PROCEED TO CHECKOUT'),
                          ),
                        ),
                        if (cart.deliveryCharge > 0) ...[
                          const SizedBox(height: 8),
                          Text('Add ₹${(999 - cart.subtotal).toStringAsFixed(0)} more for FREE delivery',
                              style: const TextStyle(fontSize: 12, color: AppColors.textSecondary), textAlign: TextAlign.center),
                        ],
                      ],
                    ),
                  ),
                ),
              ],
            ),
    );
  }
}

class _QtyBtn extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _QtyBtn({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 32,
        height: 32,
        decoration: BoxDecoration(border: Border.all(color: AppColors.divider)),
        child: Icon(icon, size: 16),
      ),
    );
  }
}

class _SummaryRow extends StatelessWidget {
  final String label, value;
  final bool bold;
  final Color? valueColor;
  const _SummaryRow(this.label, this.value, {this.bold = false, this.valueColor});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: TextStyle(fontSize: bold ? 15 : 14, fontWeight: bold ? FontWeight.w700 : FontWeight.w400, color: bold ? AppColors.textPrimary : AppColors.textSecondary)),
        Text(value, style: TextStyle(fontSize: bold ? 16 : 14, fontWeight: FontWeight.w700, color: valueColor ?? AppColors.textPrimary)),
      ],
    );
  }
}
