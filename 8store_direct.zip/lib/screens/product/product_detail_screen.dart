import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../config/app_theme.dart';
import '../../models/models.dart';
import '../../providers/cart_provider.dart';
import '../../providers/product_provider.dart';

class ProductDetailScreen extends StatefulWidget {
  final String productId;
  const ProductDetailScreen({super.key, required this.productId});

  @override
  State<ProductDetailScreen> createState() => _ProductDetailScreenState();
}

class _ProductDetailScreenState extends State<ProductDetailScreen> {
  ProductModel? _product;
  bool _loading = true;
  int _imageIndex = 0;
  String? _selectedSize;

  @override
  void initState() {
    super.initState();
    _loadProduct();
  }

  Future<void> _loadProduct() async {
    final product = await context.read<ProductProvider>().getProduct(widget.productId);
    if (mounted) setState(() { _product = product; _loading = false; });
  }

  void _addToCart() {
    if (_selectedSize == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select a size'), backgroundColor: AppColors.primary),
      );
      return;
    }
    context.read<CartProvider>().addItem(_product!, _selectedSize!);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Text('Added to cart!'),
        backgroundColor: AppColors.success,
        action: SnackBarAction(label: 'VIEW CART', textColor: Colors.white, onPressed: () => context.go('/cart')),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator(color: AppColors.primary)));
    }
    if (_product == null) {
      return Scaffold(appBar: AppBar(), body: const Center(child: Text('Product not found')));
    }

    final p = _product!;
    final sizes = ['130', '140', '150', '160', '170'];

    return Scaffold(
      backgroundColor: AppColors.background,
      body: CustomScrollView(
        slivers: [
          // Image Gallery App Bar
          SliverAppBar(
            expandedHeight: 400,
            pinned: true,
            backgroundColor: AppColors.background,
            leading: Container(
              margin: const EdgeInsets.all(8),
              decoration: BoxDecoration(color: Colors.white, shape: BoxShape.circle, boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 8)]),
              child: IconButton(icon: const Icon(Icons.arrow_back_ios, size: 16), onPressed: () => context.pop()),
            ),
            flexibleSpace: FlexibleSpaceBar(
              background: Stack(
                children: [
                  // Main image
                  PageView.builder(
                    itemCount: p.images.length,
                    onPageChanged: (idx) => setState(() => _imageIndex = idx),
                    itemBuilder: (_, idx) => CachedNetworkImage(
                      imageUrl: p.images[idx],
                      fit: BoxFit.cover,
                      placeholder: (_, __) => Container(color: AppColors.cardBg),
                      errorWidget: (_, __, ___) => Container(color: AppColors.cardBg),
                    ),
                  ),
                  // Thumbnails
                  if (p.images.length > 1)
                    Positioned(
                      bottom: 16,
                      right: 16,
                      child: Column(
                        children: List.generate(p.images.length, (idx) => GestureDetector(
                          child: Container(
                            width: 44,
                            height: 44,
                            margin: const EdgeInsets.only(bottom: 6),
                            decoration: BoxDecoration(
                              border: Border.all(color: _imageIndex == idx ? AppColors.primary : Colors.white, width: 2),
                            ),
                            child: CachedNetworkImage(imageUrl: p.images[idx], fit: BoxFit.cover),
                          ),
                        )),
                      ),
                    ),
                ],
              ),
            ),
          ),

          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Name & Price
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: Text(p.name, style: Theme.of(context).textTheme.headlineLarge),
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text('₹${p.price.toStringAsFixed(0)}', style: const TextStyle(fontFamily: 'Playfair', fontSize: 22, fontWeight: FontWeight.w700)),
                          if (p.mrp != null)
                            Text('₹${p.mrp!.toStringAsFixed(0)}', style: const TextStyle(fontSize: 13, decoration: TextDecoration.lineThrough, color: AppColors.textSecondary)),
                        ],
                      ),
                    ],
                  ),

                  if (p.mrp != null) ...[
                    const SizedBox(height: 4),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                      color: const Color(0xFFE8F5E9),
                      child: Text('${p.discountPercent.toStringAsFixed(0)}% OFF', style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: AppColors.success)),
                    ),
                  ],

                  const SizedBox(height: 24),
                  const Divider(color: AppColors.divider),
                  const SizedBox(height: 20),

                  // Size Selection
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('SELECT SIZE', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, letterSpacing: 1.5)),
                      Text('Sizes are in CM', style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 10,
                    runSpacing: 10,
                    children: sizes.map((size) {
                      final stock = p.stockForSize(size);
                      final isAvailable = stock > 0;
                      final isSelected = _selectedSize == size;
                      return GestureDetector(
                        onTap: isAvailable ? () => setState(() => _selectedSize = size) : null,
                        child: Container(
                          width: 60,
                          height: 44,
                          decoration: BoxDecoration(
                            color: isSelected ? AppColors.primary : (isAvailable ? AppColors.surface : AppColors.cardBg),
                            border: Border.all(color: isSelected ? AppColors.primary : AppColors.divider),
                          ),
                          child: Center(
                            child: Text(
                              size,
                              style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w600,
                                color: isSelected ? Colors.white : (isAvailable ? AppColors.textPrimary : AppColors.textSecondary),
                                decoration: isAvailable ? null : TextDecoration.lineThrough,
                              ),
                            ),
                          ),
                        ),
                      );
                    }).toList(),
                  ),

                  const SizedBox(height: 24),
                  const Divider(color: AppColors.divider),
                  const SizedBox(height: 20),

                  // Description
                  if (p.description.isNotEmpty) ...[
                    const Text('DESCRIPTION', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, letterSpacing: 1.5)),
                    const SizedBox(height: 10),
                    Text(p.description, style: const TextStyle(fontSize: 14, color: AppColors.textSecondary, height: 1.6)),
                    const SizedBox(height: 20),
                  ],

                  // Stock status
                  if (!p.hasStock)
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(12),
                      color: const Color(0xFFFFF3F3),
                      child: const Text('Out of Stock', style: TextStyle(color: AppColors.error, fontWeight: FontWeight.w600, fontSize: 14), textAlign: TextAlign.center),
                    ),

                  const SizedBox(height: 100), // space for button
                ],
              ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: p.hasStock
          ? Container(
              padding: const EdgeInsets.all(20).copyWith(bottom: MediaQuery.of(context).padding.bottom + 20),
              decoration: const BoxDecoration(
                color: AppColors.surface,
                border: Border(top: BorderSide(color: AppColors.divider)),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(color: AppColors.primary),
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
                      ),
                      onPressed: _addToCart,
                      child: const Text('ADD TO CART', style: TextStyle(fontWeight: FontWeight.w700, letterSpacing: 1, color: AppColors.primary)),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () {
                        _addToCart();
                        context.go('/cart');
                      },
                      child: const Text('BUY NOW'),
                    ),
                  ),
                ],
              ),
            )
          : null,
    );
  }
}
