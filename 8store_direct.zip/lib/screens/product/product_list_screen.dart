import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../config/app_theme.dart';
import '../../models/models.dart';
import '../../providers/product_provider.dart';

class ProductListScreen extends StatefulWidget {
  final String? category;
  const ProductListScreen({super.key, this.category});

  @override
  State<ProductListScreen> createState() => _ProductListScreenState();
}

class _ProductListScreenState extends State<ProductListScreen> {
  String? _selectedCategory;

  @override
  void initState() {
    super.initState();
    _selectedCategory = widget.category;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: Text(_selectedCategory != null
            ? CategoryModel.defaults.firstWhere((c) => c.id == _selectedCategory, orElse: () => CategoryModel(id: '', name: 'Shop')).name
            : 'Shop'),
        leading: _selectedCategory != null
            ? IconButton(icon: const Icon(Icons.arrow_back_ios, size: 18), onPressed: () => setState(() => _selectedCategory = null))
            : null,
      ),
      body: Column(
        children: [
          // Category Filter
          SizedBox(
            height: 48,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              children: [
                _FilterChip(label: 'All', isSelected: _selectedCategory == null, onTap: () => setState(() => _selectedCategory = null)),
                ...CategoryModel.defaults.map((c) => _FilterChip(
                  label: c.name,
                  isSelected: _selectedCategory == c.id,
                  onTap: () => setState(() => _selectedCategory = c.id),
                )),
              ],
            ),
          ),
          const Divider(height: 1, color: AppColors.divider),
          Expanded(
            child: StreamBuilder<List<ProductModel>>(
              stream: context.read<ProductProvider>().categoryStream(_selectedCategory),
              builder: (context, snap) {
                if (snap.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator(color: AppColors.primary));
                }
                final products = snap.data ?? [];
                if (products.isEmpty) {
                  return const Center(child: Text('No products found', style: TextStyle(color: AppColors.textSecondary)));
                }
                return GridView.builder(
                  padding: const EdgeInsets.all(16),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    childAspectRatio: 0.70,
                    crossAxisSpacing: 14,
                    mainAxisSpacing: 14,
                  ),
                  itemCount: products.length,
                  itemBuilder: (_, idx) => _ProductGridItem(product: products[idx]),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _FilterChip extends StatelessWidget {
  final String label;
  final bool isSelected;
  final VoidCallback onTap;
  const _FilterChip({required this.label, required this.isSelected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(right: 8),
        padding: const EdgeInsets.symmetric(horizontal: 16),
        decoration: BoxDecoration(
          color: isSelected ? AppColors.primary : AppColors.surface,
          border: Border.all(color: isSelected ? AppColors.primary : AppColors.divider),
          borderRadius: BorderRadius.circular(2),
        ),
        child: Center(
          child: Text(label, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: isSelected ? Colors.white : AppColors.textPrimary, letterSpacing: 0.5)),
        ),
      ),
    );
  }
}

class _ProductGridItem extends StatelessWidget {
  final ProductModel product;
  const _ProductGridItem({required this.product});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => context.push('/product/${product.id}'),
      child: Container(
        color: AppColors.surface,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              flex: 7,
              child: Stack(
                fit: StackFit.expand,
                children: [
                  CachedNetworkImage(
                    imageUrl: product.images.isNotEmpty ? product.images.first : '',
                    fit: BoxFit.cover,
                    placeholder: (_, __) => Container(color: AppColors.cardBg),
                    errorWidget: (_, __, ___) => Container(color: AppColors.cardBg, child: const Icon(Icons.image_not_supported_outlined, color: AppColors.textSecondary, size: 32)),
                  ),
                  if (!product.hasStock)
                    Positioned.fill(child: Container(color: Colors.white60, child: const Center(child: Text('SOLD OUT', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12, letterSpacing: 1))))),
                ],
              ),
            ),
            Expanded(
              flex: 3,
              child: Padding(
                padding: const EdgeInsets.all(8),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(product.name, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600), maxLines: 1, overflow: TextOverflow.ellipsis),
                    const SizedBox(height: 3),
                    Row(
                      children: [
                        Text('₹${product.price.toStringAsFixed(0)}', style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700)),
                        if (product.mrp != null) ...[
                          const SizedBox(width: 4),
                          Text('₹${product.mrp!.toStringAsFixed(0)}', style: const TextStyle(fontSize: 10, decoration: TextDecoration.lineThrough, color: AppColors.textSecondary)),
                        ],
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
