import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../../config/app_theme.dart';
import '../../models/models.dart';
import '../../providers/auth_provider.dart';
import '../../providers/order_provider.dart';

// ── ORDERS LIST ────────────────────────────────────────────────
class OrdersScreen extends StatefulWidget {
  const OrdersScreen({super.key});

  @override
  State<OrdersScreen> createState() => _OrdersScreenState();
}

class _OrdersScreenState extends State<OrdersScreen> {
  @override
  void initState() {
    super.initState();
    final auth = context.read<AuthProvider>();
    if (auth.user != null) {
      context.read<OrderProvider>().listenToOrders(auth.user!.id);
    }
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final orders = context.watch<OrderProvider>();

    if (auth.isGuest) {
      return Scaffold(
        appBar: AppBar(title: const Text('Orders', style: TextStyle(fontFamily: 'Playfair'))),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.receipt_long_outlined, size: 72, color: AppColors.divider),
              const SizedBox(height: 16),
              const Text('Login to view orders', style: TextStyle(fontFamily: 'Playfair', fontSize: 20, fontWeight: FontWeight.w700)),
              const SizedBox(height: 24),
              ElevatedButton(onPressed: () => context.go('/login'), child: const Text('LOGIN')),
            ],
          ),
        ),
      );
    }

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(title: const Text('My Orders', style: TextStyle(fontFamily: 'Playfair'))),
      body: orders.orders.isEmpty
          ? const Center(child: Text('No orders yet', style: TextStyle(color: AppColors.textSecondary, fontSize: 16)))
          : ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: orders.orders.length,
              separatorBuilder: (_, __) => const SizedBox(height: 12),
              itemBuilder: (_, idx) => _OrderCard(order: orders.orders[idx]),
            ),
    );
  }
}

class _OrderCard extends StatelessWidget {
  final OrderModel order;
  const _OrderCard({required this.order});

  Color _statusColor(OrderStatus s) {
    switch (s) {
      case OrderStatus.placed: return const Color(0xFF1565C0);
      case OrderStatus.packed: return const Color(0xFF6A1B9A);
      case OrderStatus.shipped: return const Color(0xFFE65100);
      case OrderStatus.delivered: return AppColors.success;
      case OrderStatus.cancelled: return AppColors.error;
    }
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => context.push('/order/${order.id}'),
      child: Container(
        padding: const EdgeInsets.all(16),
        color: AppColors.surface,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Order #${order.id.substring(0, 8).toUpperCase()}', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  color: _statusColor(order.status).withOpacity(0.1),
                  child: Text(order.status.label, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: _statusColor(order.status))),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text('${order.items.length} item(s) • ₹${order.total.toStringAsFixed(0)}',
                style: const TextStyle(fontSize: 13, color: AppColors.textSecondary)),
            const SizedBox(height: 4),
            Text(DateFormat('dd MMM yyyy, hh:mm a').format(order.createdAt),
                style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
          ],
        ),
      ),
    );
  }
}

// ── ORDER DETAIL / TRACKING ───────────────────────────────────
class OrderDetailScreen extends StatelessWidget {
  final String orderId;
  const OrderDetailScreen({super.key, required this.orderId});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('Order Tracking', style: TextStyle(fontFamily: 'Playfair')),
        leading: IconButton(icon: const Icon(Icons.arrow_back_ios, size: 18), onPressed: () => context.pop()),
      ),
      body: StreamBuilder<OrderModel>(
        stream: context.read<OrderProvider>().orderStream(orderId),
        builder: (context, snap) {
          if (!snap.hasData) return const Center(child: CircularProgressIndicator(color: AppColors.primary));
          final order = snap.data!;
          return SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Status card
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(20),
                  color: AppColors.primary,
                  child: Column(
                    children: [
                      Text(order.status.label, style: const TextStyle(fontFamily: 'Playfair', fontSize: 22, color: Colors.white, fontWeight: FontWeight.w700)),
                      const SizedBox(height: 4),
                      Text('Order #${order.id.substring(0, 8).toUpperCase()}', style: const TextStyle(fontSize: 12, color: Colors.white60, letterSpacing: 1)),
                      if (order.trackingNote != null) ...[
                        const SizedBox(height: 8),
                        Text(order.trackingNote!, style: const TextStyle(fontSize: 13, color: Colors.white70), textAlign: TextAlign.center),
                      ],
                    ],
                  ),
                ),

                const SizedBox(height: 28),

                // Tracking steps
                const Text('TRACKING', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, letterSpacing: 2)),
                const SizedBox(height: 16),
                if (order.status != OrderStatus.cancelled)
                  ...[ OrderStatus.placed, OrderStatus.packed, OrderStatus.shipped, OrderStatus.delivered ].map(
                    (s) => _TrackStep(
                      status: s,
                      isCompleted: order.status.step >= s.step,
                      isActive: order.status == s,
                      isLast: s == OrderStatus.delivered,
                    ),
                  )
                else
                  _TrackStep(status: OrderStatus.cancelled, isCompleted: true, isActive: true, isLast: true, isError: true),

                const SizedBox(height: 28),

                // Items
                const Text('ITEMS ORDERED', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, letterSpacing: 2)),
                const SizedBox(height: 12),
                ...order.items.map((item) => Container(
                  margin: const EdgeInsets.only(bottom: 8),
                  padding: const EdgeInsets.all(12),
                  color: AppColors.surface,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(child: Text('${item.productName}\nSize: ${item.size} × ${item.quantity}', style: const TextStyle(fontSize: 13))),
                      Text('₹${item.total.toStringAsFixed(0)}', style: const TextStyle(fontWeight: FontWeight.w700)),
                    ],
                  ),
                )),

                const SizedBox(height: 20),

                // Delivery address
                const Text('DELIVERY ADDRESS', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, letterSpacing: 2)),
                const SizedBox(height: 12),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(14),
                  color: AppColors.surface,
                  child: Text(order.deliveryAddress.formatted, style: const TextStyle(fontSize: 13, color: AppColors.textSecondary, height: 1.6)),
                ),

                const SizedBox(height: 20),

                // Payment summary
                const Text('PAYMENT', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, letterSpacing: 2)),
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.all(14),
                  color: AppColors.surface,
                  child: Column(
                    children: [
                      _SummaryRow('Subtotal', '₹${order.subtotal.toStringAsFixed(0)}'),
                      const SizedBox(height: 6),
                      _SummaryRow('Delivery', order.deliveryCharge == 0 ? 'FREE' : '₹${order.deliveryCharge.toStringAsFixed(0)}'),
                      const Divider(height: 20, color: AppColors.divider),
                      _SummaryRow('Total', '₹${order.total.toStringAsFixed(0)}', bold: true),
                      const SizedBox(height: 6),
                      _SummaryRow('Payment', order.paymentMethod),
                    ],
                  ),
                ),
                const SizedBox(height: 32),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _TrackStep extends StatelessWidget {
  final OrderStatus status;
  final bool isCompleted, isActive, isLast;
  final bool isError;
  const _TrackStep({required this.status, required this.isCompleted, required this.isActive, required this.isLast, this.isError = false});

  @override
  Widget build(BuildContext context) {
    final color = isError ? AppColors.error : (isCompleted ? AppColors.primary : AppColors.divider);
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Column(
          children: [
            Container(
              width: 28,
              height: 28,
              decoration: BoxDecoration(
                color: isCompleted ? color : Colors.white,
                shape: BoxShape.circle,
                border: Border.all(color: color, width: 2),
              ),
              child: isCompleted ? Icon(isError ? Icons.close : Icons.check, size: 14, color: Colors.white) : null,
            ),
            if (!isLast) Container(width: 2, height: 40, color: isCompleted ? AppColors.primary : AppColors.divider),
          ],
        ),
        const SizedBox(width: 14),
        Padding(
          padding: const EdgeInsets.only(top: 4),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(status.label, style: TextStyle(fontWeight: isActive ? FontWeight.w700 : FontWeight.w500, fontSize: 14, color: isCompleted ? AppColors.textPrimary : AppColors.textSecondary)),
              if (isActive && !isError) const Text('Current Status', style: TextStyle(fontSize: 11, color: AppColors.accent)),
            ],
          ),
        ),
      ],
    );
  }
}

class _SummaryRow extends StatelessWidget {
  final String label, value;
  final bool bold;
  const _SummaryRow(this.label, this.value, {this.bold = false});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: TextStyle(fontSize: 13, color: AppColors.textSecondary, fontWeight: bold ? FontWeight.w700 : FontWeight.w400)),
        Text(value, style: TextStyle(fontSize: bold ? 15 : 13, fontWeight: FontWeight.w700, color: AppColors.textPrimary)),
      ],
    );
  }
}
