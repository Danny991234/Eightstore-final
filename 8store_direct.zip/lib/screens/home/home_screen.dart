import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import 'package:shimmer/shimmer.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';
import '../../config/app_theme.dart';
import '../../models/models.dart';
import '../../providers/auth_provider.dart';
import '../../providers/product_provider.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _bannerIndex = 0;

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final products = context.watch<ProductProvider>();

    return Scaffold(
      backgroundColor: AppColors.background,
      body: CustomScrollView(
        slivers: [
          // App Bar
          SliverAppBar(
            floating: true,
            backgroundColor: AppColors.background,
            elevation: 0,
            title: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 28,
                  height: 28,
                  decoration: BoxDecoration(color: AppColors.primary, border: Border.all(color: AppColors.accent, width: 1)),
                  child: const Center(child: Text('8', style: TextStyle(fontFamily: 'Playfair', fontSize: 18, color: AppColors.accent, height: 1, fontWeight: FontWeight.w700))),
                ),
                const SizedBox(width: 8),
                const Text('STORE', style: TextStyle(fontFamily: 'Urbanist', fontSize: 14, fontWeight: FontWeight.w700, letterSpacing: 5, color: AppColors.primary)),
              ],
            ),
            actions: [
              IconButton(
                icon: const Icon(Icons.search, color: AppColors.primary),
                onPressed: () {},
              ),
            ],
          ),

          SliverToBoxAdapter(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Greeting
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                  child: Text(
                    auth.isGuest ? 'Hello, Guest 👋' : 'Hello, ${auth.user?.name.isEmpty == true ? 'Fashionista' : auth.user?.name} 👋',
                    style: const TextStyle(fontSize: 15, color: AppColors.textSecondary),
                  ),
                ),

                // Banner Slider
                if (products.banners.isNotEmpty) ...[
                  CarouselSlider(
                    options: CarouselOptions(
                      height: 180,
                      viewportFraction: 0.92,
                      autoPlay: true,
                      autoPlayInterval: const Duration(seconds: 4),
                      enlargeCenterPage: true,
                      onPageChanged: (idx, _) => setState(() => _bannerIndex = idx),
                    ),
                    items: products.banners.map((banner) => _BannerCard(banner: banner)).toList(),
                  ),
                  const SizedBox(height: 12),
                  Center(
                    child: AnimatedSmoothIndicator(
                      activeIndex: _bannerIndex,
                      count: products.banners.length,
                      effect: const WormEffect(
                        dotHeight: 6, dotWidth: 6,
                        activeDotColor: AppColors.primary,
                        dotColor: AppColors.divider,
                      ),
                    ),
                  ),
                ] else _BannerShimmer(),

                const SizedBox(height: 28),

                // Categories
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('CATEGORIES', style: TextStyle(fontFamily: 'Urbanist', fontSize: 12, fontWeight: FontWeight.w700, letterSpacing: 2)),
                      TextButton(onPressed: () => context.go('/products'), child: const Text('See All', style: TextStyle(color: AppColors.accent, fontSize: 13, fontWeight: FontWeight.w600))),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
                SizedBox(
                  height: 90,
                  child: ListView.separated(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    scrollDirection: Axis.horizontal,
                    itemCount: CategoryModel.defaults.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 12),
                    itemBuilder: (_, idx) => _CategoryChip(category: CategoryModel.defaults[idx]),
                  ),
                ),

                const SizedBox(height: 28),

                // Featured Products
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('FEATURED', style: TextStyle(fontFamily: 'Urbanist', fontSize: 12, fontWeight: FontWeight.w700, letterSpacing: 2)),
                      TextButton(onPressed: () => context.go('/products'), child: const Text('See All', style: TextStyle(color: AppColors.accent, fontSize: 13, fontWeight: FontWeight.w600))),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
                products.featured.isEmpty
                    ? _ProductsShimmer()
                    : SizedBox(
                        height: 240,
                        child: ListView.separated(
                          padding: const EdgeInsets.symmetric(horizontal: 20),
                          scrollDirection: Axis.horizontal,
                          itemCount: products.featured.length,
                          separatorBuilder: (_, __) => const SizedBox(width: 14),
                          itemBuilder: (_, idx) => _ProductCard(product: products.featured[idx]),
                        ),
                      ),

                const SizedBox(height: 28),

                // New Arrivals
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('NEW ARRIVALS', style: TextStyle(fontFamily: 'Urbanist', fontSize: 12, fontWeight: FontWeight.w700, letterSpacing: 2)),
                      TextButton(onPressed: () => context.go('/products'), child: const Text('See All', style: TextStyle(color: AppColors.accent, fontSize: 13, fontWeight: FontWeight.w600))),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
                products.newArrivals.isEmpty
                    ? _ProductsShimmer()
                    : GridView.builder(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 2,
                          childAspectRatio: 0.72,
                          crossAxisSpacing: 14,
                          mainAxisSpacing: 14,
                        ),
                        itemCount: products.newArrivals.length,
                        itemBuilder: (_, idx) => _ProductGridCard(product: products.newArrivals[idx]),
                      ),
                const SizedBox(height: 32),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _BannerCard extends StatelessWidget {
  final BannerModel banner;
  const _BannerCard({required this.banner});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 4),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(4),
        child: CachedNetworkImage(
          imageUrl: banner.imageUrl,
          fit: BoxFit.cover,
          width: double.infinity,
          placeholder: (_, __) => Container(color: AppColors.cardBg),
          errorWidget: (_, __, ___) => Container(
            color: AppColors.primary,
            child: const Center(child: Text('8 STORE', style: TextStyle(fontFamily: 'Playfair', fontSize: 24, color: AppColors.accent, fontWeight: FontWeight.w700))),
          ),
        ),
      ),
    );
  }
}

class _CategoryChip extends StatelessWidget {
  final CategoryModel category;
  const _CategoryChip({required this.category});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => context.go('/products?category=${category.id}'),
      child: Container(
        width: 70,
        decoration: BoxDecoration(
          color: AppColors.surface,
          border: Border.all(color: AppColors.divider),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(category.icon ?? '👗', style: const TextStyle(fontSize: 28)),
            const SizedBox(height: 4),
            Text(category.name, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w600), textAlign: TextAlign.center, maxLines: 1, overflow: TextOverflow.ellipsis),
          ],
        ),
      ),
    );
  }
}

class _ProductCard extends StatelessWidget {
  final ProductModel product;
  const _ProductCard({required this.product});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => context.push('/product/${product.id}'),
      child: Container(
        width: 160,
        color: AppColors.surface,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: CachedNetworkImage(
                imageUrl: product.images.isNotEmpty ? product.images.first : '',
                fit: BoxFit.cover,
                width: double.infinity,
                placeholder: (_, __) => Container(color: AppColors.cardBg),
                errorWidget: (_, __, ___) => Container(color: AppColors.cardBg, child: const Icon(Icons.image_not_supported_outlined, color: AppColors.textSecondary)),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(product.name, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600), maxLines: 1, overflow: TextOverflow.ellipsis),
                  const SizedBox(height: 4),
                  Text('₹${product.price.toStringAsFixed(0)}', style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.primary)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ProductGridCard extends StatelessWidget {
  final ProductModel product;
  const _ProductGridCard({required this.product});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => context.push('/product/${product.id}'),
      child: Container(
        color: AppColors.surface,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: Stack(
                children: [
                  CachedNetworkImage(
                    imageUrl: product.images.isNotEmpty ? product.images.first : '',
                    fit: BoxFit.cover,
                    width: double.infinity,
                    height: double.infinity,
                    placeholder: (_, __) => Container(color: AppColors.cardBg),
                    errorWidget: (_, __, ___) => Container(color: AppColors.cardBg),
                  ),
                  if (product.isNewArrival)
                    Positioned(top: 8, left: 8, child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
                      color: AppColors.accent,
                      child: const Text('NEW', style: TextStyle(fontSize: 9, fontWeight: FontWeight.w700, color: Colors.white, letterSpacing: 1)),
                    )),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(product.name, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600), maxLines: 1, overflow: TextOverflow.ellipsis),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      Text('₹${product.price.toStringAsFixed(0)}', style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700)),
                      if (product.mrp != null) ...[
                        const SizedBox(width: 6),
                        Text('₹${product.mrp!.toStringAsFixed(0)}', style: const TextStyle(fontSize: 11, decoration: TextDecoration.lineThrough, color: AppColors.textSecondary)),
                      ],
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _BannerShimmer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Shimmer.fromColors(
      baseColor: AppColors.cardBg,
      highlightColor: AppColors.surface,
      child: Container(height: 180, margin: const EdgeInsets.symmetric(horizontal: 16), color: AppColors.cardBg),
    );
  }
}

class _ProductsShimmer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 240,
      child: ListView.separated(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        scrollDirection: Axis.horizontal,
        itemCount: 3,
        separatorBuilder: (_, __) => const SizedBox(width: 14),
        itemBuilder: (_, __) => Shimmer.fromColors(
          baseColor: AppColors.cardBg,
          highlightColor: AppColors.surface,
          child: Container(width: 160, color: AppColors.cardBg),
        ),
      ),
    );
  }
}
