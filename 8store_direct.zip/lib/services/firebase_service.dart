import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'dart:io';
import '../models/models.dart';

class FirebaseService {
  static final _auth = FirebaseAuth.instance;
  static final _db = FirebaseFirestore.instance;
  static final _storage = FirebaseStorage.instance;

  // ── AUTH ──────────────────────────────────────────────────
  static Future<void> sendOtp({
    required String phone,
    required Function(String verificationId) onCodeSent,
    required Function(String error) onError,
  }) async {
    await _auth.verifyPhoneNumber(
      phoneNumber: phone,
      verificationCompleted: (PhoneAuthCredential cred) async {
        await _auth.signInWithCredential(cred);
      },
      verificationFailed: (FirebaseAuthException e) => onError(e.message ?? 'OTP Failed'),
      codeSent: (String vid, int? token) => onCodeSent(vid),
      codeAutoRetrievalTimeout: (_) {},
    );
  }

  static Future<UserCredential> verifyOtp(String verificationId, String smsCode) {
    final credential = PhoneAuthProvider.credential(
      verificationId: verificationId,
      smsCode: smsCode,
    );
    return _auth.signInWithCredential(credential);
  }

  static Future<void> signOut() => _auth.signOut();
  static User? get currentUser => _auth.currentUser;

  // ── USERS ─────────────────────────────────────────────────
  static Future<UserModel?> getUser(String uid) async {
    final doc = await _db.collection('users').doc(uid).get();
    if (!doc.exists) return null;
    return UserModel.fromMap({'id': doc.id, ...doc.data()!});
  }

  static Future<void> createUser(UserModel user) async {
    await _db.collection('users').doc(user.id).set(user.toMap());
  }

  static Future<void> updateUser(UserModel user) async {
    await _db.collection('users').doc(user.id).update(user.toMap());
  }

  // ── PRODUCTS ──────────────────────────────────────────────
  static Stream<List<ProductModel>> productsStream({String? category}) {
    Query<Map<String, dynamic>> q = _db.collection('products').where('isActive', isEqualTo: true);
    if (category != null) q = q.where('category', isEqualTo: category);
    return q.snapshots().map((snap) => snap.docs
        .map((doc) => ProductModel.fromMap({'id': doc.id, ...doc.data()}))
        .toList());
  }

  static Stream<List<ProductModel>> featuredProductsStream() {
    return _db.collection('products')
        .where('isActive', isEqualTo: true)
        .where('isFeatured', isEqualTo: true)
        .limit(10)
        .snapshots()
        .map((snap) => snap.docs
            .map((d) => ProductModel.fromMap({'id': d.id, ...d.data()}))
            .toList());
  }

  static Stream<List<ProductModel>> newArrivalsStream() {
    return _db.collection('products')
        .where('isActive', isEqualTo: true)
        .where('isNewArrival', isEqualTo: true)
        .orderBy('createdAt', descending: true)
        .limit(10)
        .snapshots()
        .map((snap) => snap.docs
            .map((d) => ProductModel.fromMap({'id': d.id, ...d.data()}))
            .toList());
  }

  static Future<ProductModel?> getProduct(String id) async {
    final doc = await _db.collection('products').doc(id).get();
    if (!doc.exists) return null;
    return ProductModel.fromMap({'id': doc.id, ...doc.data()!});
  }

  // ── BANNERS ───────────────────────────────────────────────
  static Stream<List<BannerModel>> bannersStream() {
    return _db.collection('banners')
        .where('isActive', isEqualTo: true)
        .orderBy('order')
        .snapshots()
        .map((snap) => snap.docs
            .map((d) => BannerModel.fromMap({'id': d.id, ...d.data()}))
            .toList());
  }

  // ── ORDERS ────────────────────────────────────────────────
  static Future<String> createOrder(OrderModel order) async {
    final ref = _db.collection('orders').doc();
    final newOrder = OrderModel(
      id: ref.id,
      userId: order.userId,
      userPhone: order.userPhone,
      items: order.items,
      deliveryAddress: order.deliveryAddress,
      subtotal: order.subtotal,
      deliveryCharge: order.deliveryCharge,
      total: order.total,
      paymentMethod: order.paymentMethod,
      createdAt: DateTime.now(),
    );
    await ref.set(newOrder.toMap());
    // Update stock
    final batch = _db.batch();
    for (final item in order.items) {
      final productRef = _db.collection('products').doc(item.productId);
      batch.update(productRef, {
        'stock.${item.size}': FieldValue.increment(-item.quantity),
      });
    }
    await batch.commit();
    return ref.id;
  }

  static Stream<List<OrderModel>> userOrdersStream(String userId) {
    return _db.collection('orders')
        .where('userId', isEqualTo: userId)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snap) => snap.docs
            .map((d) => OrderModel.fromMap({'id': d.id, ...d.data()}))
            .toList());
  }

  static Stream<OrderModel> orderStream(String orderId) {
    return _db.collection('orders').doc(orderId).snapshots().map(
      (doc) => OrderModel.fromMap({'id': doc.id, ...doc.data()!}),
    );
  }

  // ── STORAGE ───────────────────────────────────────────────
  static Future<String> uploadProductImage(File file, String productId) async {
    final ref = _storage.ref('products/$productId/${DateTime.now().millisecondsSinceEpoch}.jpg');
    await ref.putFile(file);
    return await ref.getDownloadURL();
  }

  static Future<String> uploadBannerImage(File file) async {
    final ref = _storage.ref('banners/${DateTime.now().millisecondsSinceEpoch}.jpg');
    await ref.putFile(file);
    return await ref.getDownloadURL();
  }
}
