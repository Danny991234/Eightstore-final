class CartItem {
  final String productId;
  final String productName;
  final String productImage;
  final double price;
  final String size;
  int quantity;

  CartItem({
    required this.productId,
    required this.productName,
    required this.productImage,
    required this.price,
    required this.size,
    this.quantity = 1,
  });

  double get total => price * quantity;

  Map<String, dynamic> toMap() => {
    'productId': productId,
    'productName': productName,
    'productImage': productImage,
    'price': price,
    'size': size,
    'quantity': quantity,
  };

  factory CartItem.fromMap(Map<String, dynamic> map) => CartItem(
    productId: map['productId'],
    productName: map['productName'],
    productImage: map['productImage'],
    price: (map['price'] ?? 0).toDouble(),
    size: map['size'],
    quantity: map['quantity'] ?? 1,
  );
}
