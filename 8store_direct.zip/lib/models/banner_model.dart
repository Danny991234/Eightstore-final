import 'package:cloud_firestore/cloud_firestore.dart';

class BannerModel {
  final String id;
  final String imageUrl;
  final String? link;
  final int order;
  final bool isActive;

  BannerModel({
    required this.id,
    required this.imageUrl,
    this.link,
    this.order = 0,
    this.isActive = true,
  });

  factory BannerModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return BannerModel(
      id: doc.id,
      imageUrl: data['imageUrl'] ?? '',
      link: data['link'],
      order: data['order'] ?? 0,
      isActive: data['isActive'] ?? true,
    );
  }

  Map<String, dynamic> toFirestore() => {
    'imageUrl': imageUrl,
    'link': link,
    'order': order,
    'isActive': isActive,
  };
}
