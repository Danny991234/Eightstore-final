import 'package:cloud_firestore/cloud_firestore.dart';
import 'order_model.dart';

class UserModel {
  final String uid;
  final String phone;
  final String? name;
  final String? email;
  final List<AddressModel> addresses;
  final DateTime createdAt;

  UserModel({
    required this.uid,
    required this.phone,
    this.name,
    this.email,
    this.addresses = const [],
    required this.createdAt,
  });

  factory UserModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return UserModel(
      uid: doc.id,
      phone: data['phone'] ?? '',
      name: data['name'],
      email: data['email'],
      addresses: (data['addresses'] as List<dynamic>? ?? [])
          .map((e) => AddressModel.fromMap(Map<String, dynamic>.from(e)))
          .toList(),
      createdAt: (data['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
    );
  }

  Map<String, dynamic> toFirestore() => {
    'phone': phone,
    'name': name,
    'email': email,
    'addresses': addresses.map((e) => e.toMap()).toList(),
    'createdAt': Timestamp.fromDate(createdAt),
  };
}
