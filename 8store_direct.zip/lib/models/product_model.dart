import 'package:cloud_firestore/cloud_firestore.dart';

class ProductModel {
  final String id;
  final String name;
  final String description;
  final double price;
  final double? originalPrice;
  final List<String> images;
  final List<String> sizes;  // e.g. ["130","140","150","160","170"]
  final Map<String, int> stock; // size -> quantity
  final String category;
  final bool isNewArrival;
  final bool isFeatured;
  final DateTime createdAt;

  ProductModel({
    required this.id,
    required this.name,
    required this.description,
    required this.price,
    this.originalPrice,
    required this.images,
    required this.sizes,
    required this.stock,
    required this.category,
    this.isNewArrival = false,
    this.isFeatured = false,
    required this.createdAt,
  });

  bool get isInStock => stock.values.any((qty) => qty > 0);

  int stockForSize(String size) => stock[size] ?? 0;

  double get discountPercent {
    if (originalPrice == null || originalPrice! <= price) return 0;
    return ((originalPrice! - price) / originalPrice! * 100);
  }

  factory ProductModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return ProductModel(
      id: doc.id,
      name: data['name'] ?? '',
      description: data['description'] ?? '',
      price: (data['price'] ?? 0).toDouble(),
      originalPrice: data['originalPrice']?.toDouble(),
      images: List<String>.from(data['images'] ?? []),
      sizes: List<String>.from(data['sizes'] ?? []),
      stock: Map<String, int>.from(data['stock'] ?? {}),
      category: data['category'] ?? '',
      isNewArrival: data['isNewArrival'] ?? false,
      isFeatured: data['isFeatured'] ?? false,
      createdAt: (data['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
    );
  }

  Map<String, dynamic> toFirestore() => {
    'name': name,
    'description': description,
    'price': price,
    'originalPrice': originalPrice,
    'images': images,
    'sizes': sizes,
    'stock': stock,
    'category': category,
    'isNewArrival': isNewArrival,
    'isFeatured': isFeatured,
    'createdAt': Timestamp.fromDate(createdAt),
  };
}
