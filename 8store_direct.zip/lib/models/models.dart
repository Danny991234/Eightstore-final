// ============================================================
// DATA MODELS FOR 8 STORE
// ============================================================

// ---- USER MODEL ----
class UserModel {
  final String id;
  final String phone;
  String name;
  String email;
  List<AddressModel> addresses;
  String? fcmToken;
  final DateTime createdAt;

  UserModel({
    required this.id,
    required this.phone,
    this.name = '',
    this.email = '',
    this.addresses = const [],
    this.fcmToken,
    required this.createdAt,
  });

  factory UserModel.fromMap(Map<String, dynamic> map) => UserModel(
    id: map['id'] ?? '',
    phone: map['phone'] ?? '',
    name: map['name'] ?? '',
    email: map['email'] ?? '',
    addresses: (map['addresses'] as List<dynamic>? ?? [])
        .map((a) => AddressModel.fromMap(a))
        .toList(),
    fcmToken: map['fcmToken'],
    createdAt: (map['createdAt'] as dynamic)?.toDate() ?? DateTime.now(),
  );

  Map<String, dynamic> toMap() => {
    'id': id,
    'phone': phone,
    'name': name,
    'email': email,
    'addresses': addresses.map((a) => a.toMap()).toList(),
    'fcmToken': fcmToken,
    'createdAt': createdAt,
  };
}

// ---- ADDRESS MODEL ----
class AddressModel {
  final String id;
  String fullName;
  String phone;
  String line1;
  String line2;
  String city;
  String state;
  String pincode;
  bool isDefault;

  AddressModel({
    required this.id,
    required this.fullName,
    required this.phone,
    required this.line1,
    this.line2 = '',
    required this.city,
    required this.state,
    required this.pincode,
    this.isDefault = false,
  });

  factory AddressModel.fromMap(Map<String, dynamic> map) => AddressModel(
    id: map['id'] ?? '',
    fullName: map['fullName'] ?? '',
    phone: map['phone'] ?? '',
    line1: map['line1'] ?? '',
    line2: map['line2'] ?? '',
    city: map['city'] ?? '',
    state: map['state'] ?? '',
    pincode: map['pincode'] ?? '',
    isDefault: map['isDefault'] ?? false,
  );

  Map<String, dynamic> toMap() => {
    'id': id,
    'fullName': fullName,
    'phone': phone,
    'line1': line1,
    'line2': line2,
    'city': city,
    'state': state,
    'pincode': pincode,
    'isDefault': isDefault,
  };

  String get formatted => '$fullName\n$line1${line2.isNotEmpty ? ', $line2' : ''}\n$city, $state - $pincode\nPhone: $phone';
}

// ---- PRODUCT MODEL ----
class ProductModel {
  final String id;
  String name;
  String description;
  double price;
  double? mrp;
  List<String> images;
  String category;
  Map<String, int> stock; // size -> quantity e.g. {'130': 5, '140': 3}
  List<String> availableSizes; // ['130','140','150','160','170']
  bool isActive;
  bool isFeatured;
  bool isNewArrival;
  final DateTime createdAt;

  ProductModel({
    required this.id,
    required this.name,
    this.description = '',
    required this.price,
    this.mrp,
    this.images = const [],
    required this.category,
    this.stock = const {},
    this.availableSizes = const [],
    this.isActive = true,
    this.isFeatured = false,
    this.isNewArrival = false,
    required this.createdAt,
  });

  int stockForSize(String size) => stock[size] ?? 0;
  bool get hasStock => stock.values.any((qty) => qty > 0);
  double get discountPercent => mrp != null ? ((mrp! - price) / mrp! * 100) : 0;

  factory ProductModel.fromMap(Map<String, dynamic> map) => ProductModel(
    id: map['id'] ?? '',
    name: map['name'] ?? '',
    description: map['description'] ?? '',
    price: (map['price'] ?? 0).toDouble(),
    mrp: map['mrp']?.toDouble(),
    images: List<String>.from(map['images'] ?? []),
    category: map['category'] ?? '',
    stock: Map<String, int>.from(map['stock'] ?? {}),
    availableSizes: List<String>.from(map['availableSizes'] ?? []),
    isActive: map['isActive'] ?? true,
    isFeatured: map['isFeatured'] ?? false,
    isNewArrival: map['isNewArrival'] ?? false,
    createdAt: (map['createdAt'] as dynamic)?.toDate() ?? DateTime.now(),
  );

  Map<String, dynamic> toMap() => {
    'id': id,
    'name': name,
    'description': description,
    'price': price,
    'mrp': mrp,
    'images': images,
    'category': category,
    'stock': stock,
    'availableSizes': availableSizes,
    'isActive': isActive,
    'isFeatured': isFeatured,
    'isNewArrival': isNewArrival,
    'createdAt': createdAt,
  };
}

// ---- CART ITEM MODEL ----
class CartItem {
  final String productId;
  final String productName;
  final String productImage;
  final double price;
  final String size;
  int quantity;

  CartItem({
    required this.productId,
    required this.productName,
    required this.productImage,
    required this.price,
    required this.size,
    required this.quantity,
  });

  double get total => price * quantity;
  String get cartKey => '${productId}_$size';

  factory CartItem.fromMap(Map<String, dynamic> map) => CartItem(
    productId: map['productId'],
    productName: map['productName'],
    productImage: map['productImage'],
    price: (map['price'] as num).toDouble(),
    size: map['size'],
    quantity: map['quantity'],
  );

  Map<String, dynamic> toMap() => {
    'productId': productId,
    'productName': productName,
    'productImage': productImage,
    'price': price,
    'size': size,
    'quantity': quantity,
  };
}

// ---- ORDER MODEL ----
class OrderModel {
  final String id;
  final String userId;
  final String userPhone;
  final List<CartItem> items;
  final AddressModel deliveryAddress;
  final double subtotal;
  final double deliveryCharge;
  final double total;
  final String paymentMethod; // 'COD', 'ONLINE'
  OrderStatus status;
  final DateTime createdAt;
  DateTime? updatedAt;
  String? trackingNote;

  OrderModel({
    required this.id,
    required this.userId,
    required this.userPhone,
    required this.items,
    required this.deliveryAddress,
    required this.subtotal,
    this.deliveryCharge = 0,
    required this.total,
    this.paymentMethod = 'COD',
    this.status = OrderStatus.placed,
    required this.createdAt,
    this.updatedAt,
    this.trackingNote,
  });

  factory OrderModel.fromMap(Map<String, dynamic> map) => OrderModel(
    id: map['id'],
    userId: map['userId'],
    userPhone: map['userPhone'],
    items: (map['items'] as List).map((i) => CartItem.fromMap(i)).toList(),
    deliveryAddress: AddressModel.fromMap(map['deliveryAddress']),
    subtotal: (map['subtotal'] as num).toDouble(),
    deliveryCharge: (map['deliveryCharge'] as num? ?? 0).toDouble(),
    total: (map['total'] as num).toDouble(),
    paymentMethod: map['paymentMethod'] ?? 'COD',
    status: OrderStatus.values.firstWhere(
      (s) => s.name == map['status'],
      orElse: () => OrderStatus.placed,
    ),
    createdAt: (map['createdAt'] as dynamic)?.toDate() ?? DateTime.now(),
    updatedAt: (map['updatedAt'] as dynamic)?.toDate(),
    trackingNote: map['trackingNote'],
  );

  Map<String, dynamic> toMap() => {
    'id': id,
    'userId': userId,
    'userPhone': userPhone,
    'items': items.map((i) => i.toMap()).toList(),
    'deliveryAddress': deliveryAddress.toMap(),
    'subtotal': subtotal,
    'deliveryCharge': deliveryCharge,
    'total': total,
    'paymentMethod': paymentMethod,
    'status': status.name,
    'createdAt': createdAt,
    'updatedAt': updatedAt,
    'trackingNote': trackingNote,
  };
}

enum OrderStatus { placed, packed, shipped, delivered, cancelled }

extension OrderStatusExtension on OrderStatus {
  String get label {
    switch (this) {
      case OrderStatus.placed: return 'Order Placed';
      case OrderStatus.packed: return 'Packed';
      case OrderStatus.shipped: return 'Shipped';
      case OrderStatus.delivered: return 'Delivered';
      case OrderStatus.cancelled: return 'Cancelled';
    }
  }

  int get step {
    switch (this) {
      case OrderStatus.placed: return 0;
      case OrderStatus.packed: return 1;
      case OrderStatus.shipped: return 2;
      case OrderStatus.delivered: return 3;
      case OrderStatus.cancelled: return -1;
    }
  }
}

// ---- BANNER MODEL ----
class BannerModel {
  final String id;
  final String imageUrl;
  final String? link;
  final bool isActive;
  final int order;

  BannerModel({
    required this.id,
    required this.imageUrl,
    this.link,
    this.isActive = true,
    this.order = 0,
  });

  factory BannerModel.fromMap(Map<String, dynamic> map) => BannerModel(
    id: map['id'],
    imageUrl: map['imageUrl'],
    link: map['link'],
    isActive: map['isActive'] ?? true,
    order: map['order'] ?? 0,
  );

  Map<String, dynamic> toMap() => {
    'id': id,
    'imageUrl': imageUrl,
    'link': link,
    'isActive': isActive,
    'order': order,
  };
}

// ---- CATEGORY MODEL ----
class CategoryModel {
  final String id;
  final String name;
  final String? imageUrl;
  final String? icon;

  CategoryModel({required this.id, required this.name, this.imageUrl, this.icon});

  factory CategoryModel.fromMap(Map<String, dynamic> map) => CategoryModel(
    id: map['id'],
    name: map['name'],
    imageUrl: map['imageUrl'],
    icon: map['icon'],
  );

  static List<CategoryModel> get defaults => [
    CategoryModel(id: 'shirts', name: 'Shirts', icon: '👔'),
    CategoryModel(id: 'trousers', name: 'Trousers', icon: '👖'),
    CategoryModel(id: 'jackets', name: 'Jackets', icon: '🧥'),
    CategoryModel(id: 'tshirts', name: 'T-Shirts', icon: '👕'),
    CategoryModel(id: 'accessories', name: 'Accessories', icon: '🎩'),
  ];
}

// ---- FIRESTORE EXTENSIONS ----
import 'package:cloud_firestore/cloud_firestore.dart';

extension ProductFirestore on ProductModel {
  static ProductModel fromFirestore(DocumentSnapshot doc) {
    final d = doc.data() as Map<String, dynamic>;
    return ProductModel(
      id: doc.id,
      name: d['name'] ?? '',
      description: d['description'] ?? '',
      price: (d['price'] ?? 0).toDouble(),
      mrp: d['originalPrice']?.toDouble() ?? d['mrp']?.toDouble(),
      images: List<String>.from(d['images'] ?? []),
      category: d['category'] ?? '',
      stock: Map<String, int>.from(d['stock'] ?? {}),
      availableSizes: List<String>.from(d['sizes'] ?? d['availableSizes'] ?? []),
      isActive: d['isActive'] ?? true,
      isFeatured: d['isFeatured'] ?? false,
      isNewArrival: d['isNewArrival'] ?? false,
      createdAt: (d['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
    );
  }
}

extension BannerFirestore on BannerModel {
  static BannerModel fromFirestore(DocumentSnapshot doc) {
    final d = doc.data() as Map<String, dynamic>;
    return BannerModel(
      id: doc.id,
      imageUrl: d['imageUrl'] ?? '',
      link: d['link'],
      isActive: d['isActive'] ?? true,
      order: d['order'] ?? 0,
    );
  }
}
