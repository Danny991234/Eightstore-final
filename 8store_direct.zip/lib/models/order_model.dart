import 'package:cloud_firestore/cloud_firestore.dart';
import 'cart_item_model.dart';

enum OrderStatus { placed, packed, shipped, delivered, cancelled }

extension OrderStatusExtension on OrderStatus {
  String get label {
    switch (this) {
      case OrderStatus.placed: return 'Order Placed';
      case OrderStatus.packed: return 'Packed';
      case OrderStatus.shipped: return 'Shipped';
      case OrderStatus.delivered: return 'Delivered';
      case OrderStatus.cancelled: return 'Cancelled';
    }
  }
  
  int get step {
    switch (this) {
      case OrderStatus.placed: return 0;
      case OrderStatus.packed: return 1;
      case OrderStatus.shipped: return 2;
      case OrderStatus.delivered: return 3;
      case OrderStatus.cancelled: return -1;
    }
  }
}

class AddressModel {
  final String name;
  final String phone;
  final String line1;
  final String line2;
  final String city;
  final String state;
  final String pincode;

  AddressModel({
    required this.name,
    required this.phone,
    required this.line1,
    this.line2 = '',
    required this.city,
    required this.state,
    required this.pincode,
  });

  String get fullAddress => '$line1${line2.isNotEmpty ? ", $line2" : ""}, $city, $state - $pincode';

  Map<String, dynamic> toMap() => {
    'name': name, 'phone': phone, 'line1': line1,
    'line2': line2, 'city': city, 'state': state, 'pincode': pincode,
  };

  factory AddressModel.fromMap(Map<String, dynamic> m) => AddressModel(
    name: m['name'] ?? '', phone: m['phone'] ?? '', line1: m['line1'] ?? '',
    line2: m['line2'] ?? '', city: m['city'] ?? '', state: m['state'] ?? '', pincode: m['pincode'] ?? '',
  );
}

class OrderModel {
  final String id;
  final String userId;
  final String userPhone;
  final List<CartItem> items;
  final AddressModel address;
  final double totalAmount;
  final OrderStatus status;
  final String paymentMethod;
  final DateTime createdAt;
  final DateTime? updatedAt;
  final String? trackingNote;

  OrderModel({
    required this.id,
    required this.userId,
    required this.userPhone,
    required this.items,
    required this.address,
    required this.totalAmount,
    this.status = OrderStatus.placed,
    this.paymentMethod = 'COD',
    required this.createdAt,
    this.updatedAt,
    this.trackingNote,
  });

  factory OrderModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return OrderModel(
      id: doc.id,
      userId: data['userId'] ?? '',
      userPhone: data['userPhone'] ?? '',
      items: (data['items'] as List<dynamic>? ?? [])
          .map((e) => CartItem.fromMap(Map<String, dynamic>.from(e)))
          .toList(),
      address: AddressModel.fromMap(Map<String, dynamic>.from(data['address'] ?? {})),
      totalAmount: (data['totalAmount'] ?? 0).toDouble(),
      status: OrderStatus.values.firstWhere(
        (s) => s.name == (data['status'] ?? 'placed'),
        orElse: () => OrderStatus.placed,
      ),
      paymentMethod: data['paymentMethod'] ?? 'COD',
      createdAt: (data['createdAt'] as Timestamp?)?.toDate() ?? DateTime.now(),
      updatedAt: (data['updatedAt'] as Timestamp?)?.toDate(),
      trackingNote: data['trackingNote'],
    );
  }

  Map<String, dynamic> toFirestore() => {
    'userId': userId,
    'userPhone': userPhone,
    'items': items.map((e) => e.toMap()).toList(),
    'address': address.toMap(),
    'totalAmount': totalAmount,
    'status': status.name,
    'paymentMethod': paymentMethod,
    'createdAt': Timestamp.fromDate(createdAt),
    'updatedAt': updatedAt != null ? Timestamp.fromDate(updatedAt!) : null,
    'trackingNote': trackingNote,
  };
}
