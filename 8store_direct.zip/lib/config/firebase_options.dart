// firebase_options.dart — Fully configured for 8 STORE
// Project: store-app-1a1f1

import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart' show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) return web;
    switch (defaultTargetPlatform) {
      case TargetPlatform.android: return android;
      case TargetPlatform.iOS: return ios;
      default: throw UnsupportedError('Unsupported platform.');
    }
  }

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyAnTJQR7WzD32uuGA1avCGyzI00jvXLQ4s',
    appId: '1:991219856384:android:6bf89fe3c87eec755c54e5',
    messagingSenderId: '991219856384',
    projectId: 'store-app-1a1f1',
    storageBucket: 'store-app-1a1f1.firebasestorage.app',
  );

  static const FirebaseOptions web = FirebaseOptions(
    apiKey: 'AIzaSyC4YNGyU8JHtwpahv4NRyDSMLn6b7Z4TqA',
    appId: '1:991219856384:web:4e65ab229aa214d75c54e5',
    messagingSenderId: '991219856384',
    projectId: 'store-app-1a1f1',
    storageBucket: 'store-app-1a1f1.firebasestorage.app',
    authDomain: 'store-app-1a1f1.firebaseapp.com',
    measurementId: 'G-QDPEG7JRW8',
  );

  // iOS: Add iOS app in Firebase Console if needed
  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'AIzaSyC4YNGyU8JHtwpahv4NRyDSMLn6b7Z4TqA',
    appId: '1:991219856384:ios:REPLACE_IF_NEEDED',
    messagingSenderId: '991219856384',
    projectId: 'store-app-1a1f1',
    storageBucket: 'store-app-1a1f1.firebasestorage.app',
    iosBundleId: 'com.eightstore.app',
  );
}
