import 'package:flutter/material.dart';

class AppTheme {
  // 8 STORE Brand Colors
  static const Color primary = Color(0xFF0A0A0A);       // Jet Black
  static const Color accent = Color(0xFFD4A853);         // Gold
  static const Color background = Color(0xFFFAF9F7);     // Warm White
  static const Color surface = Color(0xFFFFFFFF);
  static const Color textPrimary = Color(0xFF0A0A0A);
  static const Color textSecondary = Color(0xFF6B6B6B);
  static const Color divider = Color(0xFFE8E8E8);
  static const Color error = Color(0xFFE53E3E);
  static const Color success = Color(0xFF38A169);
  static const Color cardBg = Color(0xFFF5F4F1);

  static ThemeData get lightTheme {
    return ThemeData(
      useMaterial3: true,
      scaffoldBackgroundColor: background,
      colorScheme: const ColorScheme.light(
        primary: primary,
        secondary: accent,
        surface: surface,
        background: background,
        error: error,
      ),
      fontFamily: 'Urbanist',
      appBarTheme: const AppBarTheme(
        backgroundColor: background,
        elevation: 0,
        scrolledUnderElevation: 0,
        centerTitle: true,
        iconTheme: IconThemeData(color: primary),
        titleTextStyle: TextStyle(
          fontFamily: 'Playfair',
          fontSize: 20,
          fontWeight: FontWeight.w700,
          color: primary,
          letterSpacing: 1.5,
        ),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: primary,
          foregroundColor: Colors.white,
          elevation: 0,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
          padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 24),
          textStyle: const TextStyle(
            fontFamily: 'Urbanist',
            fontSize: 14,
            fontWeight: FontWeight.w700,
            letterSpacing: 1.5,
          ),
        ),
      ),
      textTheme: const TextTheme(
        displayLarge: TextStyle(fontFamily: 'Playfair', fontSize: 32, fontWeight: FontWeight.w700, color: textPrimary),
        displayMedium: TextStyle(fontFamily: 'Playfair', fontSize: 26, fontWeight: FontWeight.w700, color: textPrimary),
        headlineLarge: TextStyle(fontFamily: 'Playfair', fontSize: 22, fontWeight: FontWeight.w700, color: textPrimary),
        headlineMedium: TextStyle(fontFamily: 'Urbanist', fontSize: 18, fontWeight: FontWeight.w700, color: textPrimary),
        titleLarge: TextStyle(fontFamily: 'Urbanist', fontSize: 16, fontWeight: FontWeight.w600, color: textPrimary),
        titleMedium: TextStyle(fontFamily: 'Urbanist', fontSize: 14, fontWeight: FontWeight.w600, color: textPrimary),
        bodyLarge: TextStyle(fontFamily: 'Urbanist', fontSize: 15, fontWeight: FontWeight.w400, color: textPrimary),
        bodyMedium: TextStyle(fontFamily: 'Urbanist', fontSize: 14, fontWeight: FontWeight.w400, color: textSecondary),
        labelLarge: TextStyle(fontFamily: 'Urbanist', fontSize: 13, fontWeight: FontWeight.w600, letterSpacing: 1.2),
      ),
    );
  }
}

class AppColors {
  static const primary = AppTheme.primary;
  static const accent = AppTheme.accent;
  static const background = AppTheme.background;
  static const surface = AppTheme.surface;
  static const textPrimary = AppTheme.textPrimary;
  static const textSecondary = AppTheme.textSecondary;
  static const divider = AppTheme.divider;
  static const error = AppTheme.error;
  static const success = AppTheme.success;
  static const cardBg = AppTheme.cardBg;
}
