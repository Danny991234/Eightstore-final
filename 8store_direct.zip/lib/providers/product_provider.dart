import 'package:flutter/foundation.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/models.dart';

class ProductProvider extends ChangeNotifier {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  List<ProductModel> _products = [];
  List<ProductModel> _featured = [];
  List<ProductModel> _newArrivals = [];
  List<BannerModel> _banners = [];
  bool _loading = false;
  String? _error;

  List<ProductModel> get products => _products;
  List<ProductModel> get featured => _featured;
  List<ProductModel> get newArrivals => _newArrivals;
  List<BannerModel> get banners => _banners;
  bool get loading => _loading;
  String? get error => _error;

  List<String> get categories {
    final cats = _products.map((p) => p.category).toSet().toList();
    cats.sort();
    return cats;
  }

  Future<void> fetchAll() async {
    _loading = true;
    _error = null;
    notifyListeners();
    try {
      await Future.wait([fetchProducts(), fetchBanners()]);
    } catch (e) {
      _error = e.toString();
    }
    _loading = false;
    notifyListeners();
  }

  Future<void> fetchProducts() async {
    final snap = await _db.collection('products')
        .orderBy('createdAt', descending: true).get();
    _products = snap.docs.map((d) => ProductFirestore.fromFirestore(d)).toList();
    _featured = _products.where((p) => p.isFeatured).toList();
    _newArrivals = _products.where((p) => p.isNewArrival).toList();
    notifyListeners();
  }

  Future<void> fetchBanners() async {
    try {
      final snap = await _db.collection('banners')
          .where('isActive', isEqualTo: true)
          .orderBy('order').get();
      _banners = snap.docs.map((d) => BannerFirestore.fromFirestore(d)).toList();
      notifyListeners();
    } catch (e) {
      _banners = [];
    }
  }

  List<ProductModel> getByCategory(String category) =>
      _products.where((p) => p.category == category).toList();

  Future<ProductModel?> getProduct(String id) async {
    try {
      final doc = await _db.collection('products').doc(id).get();
      if (!doc.exists) return null;
      return ProductFirestore.fromFirestore(doc);
    } catch (e) { return null; }
  }
}
