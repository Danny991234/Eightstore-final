import 'package:flutter/material.dart';
import '../models/models.dart';

class CartProvider extends ChangeNotifier {
  final List<CartItem> _items = [];

  List<CartItem> get items => List.unmodifiable(_items);
  int get itemCount => _items.fold(0, (sum, item) => sum + item.quantity);
  double get subtotal => _items.fold(0, (sum, item) => sum + item.total);
  double get deliveryCharge => subtotal >= 999 ? 0 : 99;
  double get total => subtotal + deliveryCharge;
  bool get isEmpty => _items.isEmpty;

  void addItem(ProductModel product, String size) {
    final key = '${product.id}_$size';
    final existing = _items.where((i) => i.cartKey == key);
    if (existing.isNotEmpty) {
      existing.first.quantity++;
    } else {
      _items.add(CartItem(
        productId: product.id,
        productName: product.name,
        productImage: product.images.isNotEmpty ? product.images.first : '',
        price: product.price,
        size: size,
        quantity: 1,
      ));
    }
    notifyListeners();
  }

  void updateQuantity(String cartKey, int qty) {
    final idx = _items.indexWhere((i) => i.cartKey == cartKey);
    if (idx == -1) return;
    if (qty <= 0) {
      _items.removeAt(idx);
    } else {
      _items[idx].quantity = qty;
    }
    notifyListeners();
  }

  void removeItem(String cartKey) {
    _items.removeWhere((i) => i.cartKey == cartKey);
    notifyListeners();
  }

  void clear() {
    _items.clear();
    notifyListeners();
  }
}
