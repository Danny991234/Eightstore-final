import 'package:flutter/material.dart';
import '../models/models.dart';
import '../services/firebase_service.dart';

// ── PRODUCT PROVIDER ──────────────────────────────────────────
class ProductProvider extends ChangeNotifier {
  List<ProductModel> _featured = [];
  List<ProductModel> _newArrivals = [];
  List<BannerModel> _banners = [];

  List<ProductModel> get featured => _featured;
  List<ProductModel> get newArrivals => _newArrivals;
  List<BannerModel> get banners => _banners;

  ProductProvider() {
    _listenToFeatured();
    _listenToNewArrivals();
    _listenToBanners();
  }

  void _listenToFeatured() {
    FirebaseService.featuredProductsStream().listen((products) {
      _featured = products;
      notifyListeners();
    });
  }

  void _listenToNewArrivals() {
    FirebaseService.newArrivalsStream().listen((products) {
      _newArrivals = products;
      notifyListeners();
    });
  }

  void _listenToBanners() {
    FirebaseService.bannersStream().listen((banners) {
      _banners = banners;
      notifyListeners();
    });
  }

  Stream<List<ProductModel>> categoryStream(String? category) =>
      FirebaseService.productsStream(category: category);

  Future<ProductModel?> getProduct(String id) => FirebaseService.getProduct(id);
}

// ── ORDER PROVIDER ────────────────────────────────────────────
class OrderProvider extends ChangeNotifier {
  List<OrderModel> _orders = [];
  bool _isLoading = false;

  List<OrderModel> get orders => _orders;
  bool get isLoading => _isLoading;

  void listenToOrders(String userId) {
    FirebaseService.userOrdersStream(userId).listen((orders) {
      _orders = orders;
      notifyListeners();
    });
  }

  Future<String?> placeOrder(OrderModel order) async {
    _isLoading = true;
    notifyListeners();
    try {
      final orderId = await FirebaseService.createOrder(order);
      _isLoading = false;
      notifyListeners();
      return orderId;
    } catch (e) {
      _isLoading = false;
      notifyListeners();
      return null;
    }
  }

  Stream<OrderModel> orderStream(String orderId) =>
      FirebaseService.orderStream(orderId);
}
