import 'package:flutter/material.dart';
import '../models/models.dart';
import '../services/firebase_service.dart';

class AuthProvider extends ChangeNotifier {
  UserModel? _user;
  bool _isGuest = false;
  bool _isLoading = false;
  String? _verificationId;

  UserModel? get user => _user;
  bool get isLoggedIn => _user != null;
  bool get isGuest => _isGuest;
  bool get isLoading => _isLoading;

  AuthProvider() {
    _init();
  }

  Future<void> _init() async {
    final firebaseUser = FirebaseService.currentUser;
    if (firebaseUser != null) {
      _user = await FirebaseService.getUser(firebaseUser.uid);
      if (_user == null) {
        _user = UserModel(id: firebaseUser.uid, phone: firebaseUser.phoneNumber ?? '', createdAt: DateTime.now());
        await FirebaseService.createUser(_user!);
      }
      notifyListeners();
    }
  }

  Future<String?> sendOtp(String phone) async {
    _isLoading = true;
    notifyListeners();
    String? error;
    await FirebaseService.sendOtp(
      phone: phone,
      onCodeSent: (vid) {
        _verificationId = vid;
        _isLoading = false;
        notifyListeners();
      },
      onError: (e) {
        error = e;
        _isLoading = false;
        notifyListeners();
      },
    );
    return error;
  }

  Future<String?> verifyOtp(String code) async {
    if (_verificationId == null) return 'Verification session expired';
    _isLoading = true;
    notifyListeners();
    try {
      final cred = await FirebaseService.verifyOtp(_verificationId!, code);
      final uid = cred.user!.uid;
      _user = await FirebaseService.getUser(uid);
      if (_user == null) {
        _user = UserModel(
          id: uid,
          phone: cred.user!.phoneNumber ?? '',
          createdAt: DateTime.now(),
        );
        await FirebaseService.createUser(_user!);
      }
      _isGuest = false;
      _isLoading = false;
      notifyListeners();
      return null;
    } catch (e) {
      _isLoading = false;
      notifyListeners();
      return 'Invalid OTP. Please try again.';
    }
  }

  void continueAsGuest() {
    _isGuest = true;
    notifyListeners();
  }

  Future<void> signOut() async {
    await FirebaseService.signOut();
    _user = null;
    _isGuest = false;
    notifyListeners();
  }

  Future<void> updateProfile({String? name, String? email}) async {
    if (_user == null) return;
    if (name != null) _user!.name = name;
    if (email != null) _user!.email = email;
    await FirebaseService.updateUser(_user!);
    notifyListeners();
  }

  Future<void> addAddress(AddressModel address) async {
    if (_user == null) return;
    if (address.isDefault) {
      for (final a in _user!.addresses) { a.isDefault = false; }
    }
    _user!.addresses.add(address);
    await FirebaseService.updateUser(_user!);
    notifyListeners();
  }

  Future<void> removeAddress(String addressId) async {
    if (_user == null) return;
    _user!.addresses.removeWhere((a) => a.id == addressId);
    await FirebaseService.updateUser(_user!);
    notifyListeners();
  }
}
