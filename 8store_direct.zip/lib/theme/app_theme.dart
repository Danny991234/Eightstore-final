import 'package:flutter/material.dart';

class AppTheme {
  static const Color primary = Color(0xFF0A0A0A);
  static const Color secondary = Color(0xFFD4AF37);
  static const Color accent = Color(0xFFF5F0E8);
  static const Color surface = Color(0xFF1A1A1A);
  static const Color error = Color(0xFFE53935);
  static const Color success = Color(0xFF43A047);
  static const Color textPrimary = Color(0xFFF5F0E8);
  static const Color textSecondary = Color(0xFFAAAAAA);
  static const Color divider = Color(0xFF2A2A2A);

  static ThemeData get darkTheme => ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    scaffoldBackgroundColor: primary,
    colorScheme: const ColorScheme.dark(
      primary: secondary,
      secondary: secondary,
      surface: surface,
      error: error,
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: primary,
      elevation: 0,
      centerTitle: true,
      titleTextStyle: TextStyle(
        fontFamily: 'Playfair',
        fontSize: 20,
        fontWeight: FontWeight.bold,
        color: textPrimary,
        letterSpacing: 2,
      ),
      iconTheme: IconThemeData(color: textPrimary),
    ),
    textTheme: const TextTheme(
      displayLarge: TextStyle(fontFamily: 'Playfair', color: textPrimary, fontSize: 32, fontWeight: FontWeight.bold),
      displayMedium: TextStyle(fontFamily: 'Playfair', color: textPrimary, fontSize: 24, fontWeight: FontWeight.bold),
      titleLarge: TextStyle(fontFamily: 'Playfair', color: textPrimary, fontSize: 18, fontWeight: FontWeight.w600),
      titleMedium: TextStyle(fontFamily: 'Raleway', color: textPrimary, fontSize: 16, fontWeight: FontWeight.w600),
      bodyLarge: TextStyle(fontFamily: 'Raleway', color: textPrimary, fontSize: 15),
      bodyMedium: TextStyle(fontFamily: 'Raleway', color: textSecondary, fontSize: 13),
      labelLarge: TextStyle(fontFamily: 'Raleway', color: primary, fontSize: 14, fontWeight: FontWeight.bold, letterSpacing: 1.5),
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: secondary,
        foregroundColor: primary,
        minimumSize: const Size(double.infinity, 52),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
        textStyle: const TextStyle(fontFamily: 'Raleway', fontSize: 14, fontWeight: FontWeight.bold, letterSpacing: 2),
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: surface,
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(4), borderSide: const BorderSide(color: divider)),
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(4), borderSide: const BorderSide(color: divider)),
      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(4), borderSide: const BorderSide(color: secondary, width: 1.5)),
      labelStyle: const TextStyle(color: textSecondary, fontFamily: 'Raleway'),
      hintStyle: const TextStyle(color: textSecondary, fontFamily: 'Raleway'),
    ),
    cardTheme: CardTheme(
      color: surface,
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4)),
    ),
    dividerColor: divider,
    bottomNavigationBarTheme: const BottomNavigationBarThemeData(
      backgroundColor: surface,
      selectedItemColor: secondary,
      unselectedItemColor: textSecondary,
      type: BottomNavigationBarType.fixed,
      elevation: 0,
    ),
  );
}
